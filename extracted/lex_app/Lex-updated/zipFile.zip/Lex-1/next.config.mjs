/** @type {import('next').NextConfig} */
const nextConfig = {
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    unoptimized: true,
  },
  allowedDevOrigins: [
    "e5222833-3a91-4a69-a146-c4eb9454b5b4-00-1b6tp72hvee1g.janeway.replit.dev",
    "*.janeway.replit.dev",
    "*.replit.dev",
  ],
}

export default nextConfig
