"use client"

import { useState, useCallback } from "react"
import Image from "next/image"
import { Lock, ChevronUp, X, Mail, RefreshCw, Type } from "lucide-react"
import type { LockConfig } from "./utils"
import { verifyHash, clearLockConfig } from "./utils"
import { PinPad }      from "./pin"
import { PatternLock } from "./pattern"
import type { Weather } from "../app/types"
import { cn } from "@/lib/utils"

type Panel = "idle" | "unlock" | "recovery" | "recovery-email"
type ClockStyle = "thin" | "bold" | "mono" | "serif"

interface LockScreenProps {
  config:   LockConfig
  weather:  Weather | null
  time:     Date | null
  onUnlock: () => void
  onReset:  () => void
}

const CLOCK_STYLES: { key: ClockStyle; label: string; className: string }[] = [
  { key: "thin",  label: "Thin",  className: "font-thin tracking-tight"      },
  { key: "bold",  label: "Bold",  className: "font-black tracking-tighter"   },
  { key: "mono",  label: "Mono",  className: "font-mono font-medium"         },
  { key: "serif", label: "Serif", className: "font-serif font-light italic"  },
]

function BigClock({ time, style }: { time: Date | null; style: ClockStyle }) {
  const t    = time ?? new Date()
  const hh   = t.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  const date = t.toLocaleDateString([], { weekday: "long", month: "long", day: "numeric" })
  const cls  = CLOCK_STYLES.find(s => s.key === style)?.className ?? CLOCK_STYLES[0].className
  return (
    <div className="text-center text-white">
      <p className={cn("text-7xl tabular-nums leading-none", cls)}>{hh}</p>
      <p className="mt-2 text-base font-light opacity-80">{date}</p>
    </div>
  )
}

export function LockScreen({ config, weather, time, onUnlock, onReset }: LockScreenProps) {
  const [panel,       setPanel]       = useState<Panel>("idle")
  const [error,       setError]       = useState("")
  const [pwInput,     setPwInput]     = useState("")
  const [emailInput,  setEmailInput]  = useState("")
  const [attempts,    setAttempts]    = useState(0)
  const [clockStyle,  setClockStyle]  = useState<ClockStyle>("thin")
  const [styleOpen,   setStyleOpen]   = useState(false)

  const showUnlock = () => { setPanel("unlock"); setError("") }

  /* ── verify ── */
  const verify = useCallback(async (value: string) => {
    const ok = await verifyHash(value, config.lockHash)
    if (ok) {
      setError(""); setAttempts(0); onUnlock()
    } else {
      const next = attempts + 1
      setAttempts(next)
      setError(`Incorrect — ${next >= 5 ? "too many attempts, try recovery" : `${5 - next} attempts left`}`)
    }
  }, [config.lockHash, attempts, onUnlock])

  /* ── Face ID ── */
  const verifyFace = useCallback(async () => {
    if (!config.faceCredentialId) { setError("Face ID not registered."); return }
    try {
      const rawId = Uint8Array.from(atob(config.faceCredentialId), c => c.charCodeAt(0))
      const cred = await navigator.credentials.get({
        publicKey: {
          challenge:        crypto.getRandomValues(new Uint8Array(32)),
          allowCredentials: [{ type: "public-key", id: rawId }],
          userVerification: "preferred",
          timeout:          60000,
        },
      }) as PublicKeyCredential | null
      if (cred) { onUnlock() } else { setError("Face ID failed. Try again.") }
    } catch { setError("Face ID failed. Use another method.") }
  }, [config.faceCredentialId, onUnlock])

  /* ── Recovery ── */
  const handleEmailRecovery = () => {
    if (!emailInput.trim()) { setError("Enter your recovery email."); return }
    if (emailInput.toLowerCase().trim() !== config.recoveryEmail.toLowerCase().trim()) {
      setError("Email does not match your recovery email."); return
    }
    clearLockConfig(); onReset()
  }

  const bg = "bg-gradient-to-b from-stone-900 via-stone-800 to-stone-950"

  return (
    <div className={cn("relative flex h-full w-full flex-col overflow-hidden", bg)}>
      {/* ambient glow */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 size-64 rounded-full bg-orange-500/10 blur-3xl" />
      </div>

      {/* ── IDLE ── */}
      {panel === "idle" && (
        <div className="relative flex h-full flex-col items-center justify-between py-12 px-6">
          {/* top: clock style picker + clock + weather */}
          <div className="flex flex-col items-center gap-6 mt-8 w-full">
            {/* clock style picker */}
            <div className="relative w-full flex justify-center">
              <button
                onClick={() => setStyleOpen(o => !o)}
                className="flex items-center gap-1.5 rounded-full bg-white/10 px-3 py-1.5 text-[10px] font-semibold text-white/60 hover:bg-white/20 transition-colors active:scale-95"
              >
                <Type className="size-3" />
                Clock style: {CLOCK_STYLES.find(s => s.key === clockStyle)?.label}
              </button>
              {styleOpen && (
                <div className="absolute top-9 z-10 flex gap-2 rounded-2xl border border-white/15 bg-stone-900/90 p-2 backdrop-blur">
                  {CLOCK_STYLES.map(s => (
                    <button
                      key={s.key}
                      onClick={() => { setClockStyle(s.key); setStyleOpen(false) }}
                      className={cn(
                        "rounded-xl px-3 py-2 text-xs text-white transition-colors",
                        clockStyle === s.key ? "bg-white/20 font-semibold" : "hover:bg-white/10",
                      )}
                    >
                      {s.label}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <BigClock time={time} style={clockStyle} />

            {weather && (
              <div className="flex items-center gap-3 rounded-2xl bg-white/10 px-5 py-3 backdrop-blur-sm">
                <span className="text-3xl">{weather.icon}</span>
                <div className="text-white">
                  <p className="text-lg font-semibold">{weather.temp}{weather.unit} · {weather.label}</p>
                  <p className="text-xs opacity-70">{weather.city} · H{weather.high}° L{weather.low}°</p>
                </div>
              </div>
            )}
          </div>

          {/* bottom: lock */}
          <button onClick={showUnlock} className="flex flex-col items-center gap-3 group active:scale-95 transition-transform">
            <div className="flex size-14 items-center justify-center rounded-full border-2 border-white/30 bg-white/10 backdrop-blur group-hover:bg-white/20 transition-colors">
              <Lock className="size-6 text-white" />
            </div>
            <div className="flex items-center gap-1.5 text-white/70">
              <ChevronUp className="size-4 animate-bounce" />
              <span className="text-sm font-light">Tap to unlock</span>
            </div>
          </button>
        </div>
      )}

      {/* ── UNLOCK PANEL ── */}
      {panel === "unlock" && (
        <div className="relative flex h-full flex-col">
          <div className="flex items-center justify-center px-5 pt-6 pb-4">
            <BigClock time={time} style={clockStyle} />
          </div>

          <div className="flex flex-1 flex-col items-center justify-center px-5">
            {config.lockType === "face" && (
              <div className="flex flex-col items-center gap-4">
                <Image src="/lex-orb.png" alt="Face ID" width={80} height={80} className="rounded-full shadow-2xl opacity-90" />
                <p className="text-white/80 text-sm">Looking for your face…</p>
                {error && <p className="text-red-400 text-xs">{error}</p>}
                <button onClick={verifyFace} className="rounded-full border border-white/30 bg-white/10 px-6 py-2.5 text-sm text-white hover:bg-white/20 transition-colors">
                  Try Face ID
                </button>
              </div>
            )}
            {config.lockType === "pin" && (
              <div className="w-full">
                <PinPad mode="verify" onComplete={verify} error={error} label="Enter PIN" />
              </div>
            )}
            {config.lockType === "pattern" && (
              <PatternLock mode="verify" onComplete={verify} error={error} />
            )}
            {config.lockType === "password" && (
              <div className="flex w-full flex-col gap-4">
                <p className={cn("text-sm text-center", error ? "text-red-400" : "text-white/70")}>
                  {error || "Enter your password"}
                </p>
                <input
                  type="password"
                  value={pwInput}
                  onChange={e => setPwInput(e.target.value)}
                  onKeyDown={e => e.key === "Enter" && verify(pwInput)}
                  placeholder="Password…"
                  autoFocus
                  className="w-full rounded-full border border-white/20 bg-white/10 px-5 py-3 text-sm text-white placeholder:text-white/40 outline-none backdrop-blur focus:border-white/40"
                />
                <button
                  onClick={() => verify(pwInput)}
                  className="w-full rounded-full bg-white/20 py-3 text-sm font-semibold text-white hover:bg-white/30 active:scale-[0.98] transition-all"
                >
                  Unlock
                </button>
              </div>
            )}
          </div>

          <div className="flex items-center justify-between px-6 pb-6">
            <button onClick={() => { setPanel("idle"); setError("") }} className="text-white/60 text-xs hover:text-white/80">
              Cancel
            </button>
            <button onClick={() => { setPanel("recovery"); setError("") }} className="text-white/60 text-xs hover:text-white/80">
              Forgot? →
            </button>
          </div>
        </div>
      )}

      {/* ── RECOVERY ── */}
      {panel === "recovery" && (
        <div className="flex h-full flex-col items-center justify-center px-6 gap-5">
          <button onClick={() => setPanel("unlock")} className="self-start flex items-center gap-1 text-white/60 text-sm hover:text-white/80">
            ← Back
          </button>
          <RefreshCw className="size-10 text-white/70" />
          <div className="text-center">
            <p className="text-lg font-semibold text-white">Account Recovery</p>
            <p className="mt-1 text-xs text-white/60">Verify your identity to reset your lock</p>
          </div>
          <button
            onClick={() => window.location.href = "/api/auth/signin/google?callbackUrl=/lock-callback"}
            className="flex w-full items-center gap-3 rounded-2xl bg-white px-4 py-3.5 hover:bg-white/90 active:scale-[0.98] transition-all shadow-lg"
          >
            <svg className="size-5 shrink-0" viewBox="0 0 24 24">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
            </svg>
            <span className="flex-1 text-left text-sm font-semibold text-gray-800">Sign in with Google</span>
          </button>
          <button
            onClick={() => { setPanel("recovery-email"); setError("") }}
            className="flex w-full items-center gap-3 rounded-2xl border border-white/20 bg-white/10 px-4 py-3.5 hover:bg-white/20 active:scale-[0.98] transition-all backdrop-blur"
          >
            <Mail className="size-5 text-white/80 shrink-0" />
            <span className="flex-1 text-left text-sm font-medium text-white">Use recovery email</span>
          </button>
          {error && <p className="text-red-400 text-xs text-center">{error}</p>}
        </div>
      )}

      {/* ── EMAIL RECOVERY ── */}
      {panel === "recovery-email" && (
        <div className="flex h-full flex-col items-center justify-center px-6 gap-5">
          <button onClick={() => setPanel("recovery")} className="self-start text-white/60 text-sm hover:text-white/80">← Back</button>
          <Mail className="size-10 text-white/70" />
          <div className="text-center">
            <p className="text-lg font-semibold text-white">Email Recovery</p>
            <p className="mt-1 text-xs text-white/60">Enter the recovery email you set during lock setup.</p>
          </div>
          <input
            type="email"
            value={emailInput}
            onChange={e => setEmailInput(e.target.value)}
            onKeyDown={e => e.key === "Enter" && handleEmailRecovery()}
            placeholder="your@email.com"
            className="w-full rounded-full border border-white/20 bg-white/10 px-5 py-3 text-sm text-white placeholder:text-white/40 outline-none backdrop-blur focus:border-white/40"
          />
          {error && <p className="text-red-400 text-xs">{error}</p>}
          <button
            onClick={handleEmailRecovery}
            className="w-full rounded-2xl bg-white/20 py-3.5 text-sm font-semibold text-white hover:bg-white/30 active:scale-[0.98] transition-all"
          >
            Verify & Reset Lock
          </button>
        </div>
      )}
    </div>
  )
}
