"use client"

import { useState, useEffect, useRef, useCallback } from "react"
import type { Screen, Weather, Msg } from "./types"
import { HomeScreen }     from "./home"
import { LexScreen }      from "./lex-chat"
import { VoiceScreen }    from "./voice"
import { FocusScreen }    from "./focus"
import { SpaceScreen }    from "./space"
import { DrawerScreen }   from "./drawer"
import { SettingsScreen } from "./settings"
import { PaywallScreen }  from "./paywall"
import { PaymentScreen }  from "./payment"
import { WeatherSearch }  from "./weather-search"
import { NotificationPanel, buildNotifications } from "./notifications"
import type { Notification } from "./notifications"
import { LockSetup }  from "../lock/setup"
import { LockScreen } from "../lock/screen"
import { getLockConfig, clearLockConfig, type LockConfig } from "../lock/utils"
import {
  type AppSettings,
  loadSettings, saveSettings, applyAllSettings, WALLPAPERS,
} from "@/lib/settings"
import {
  getQuota, incrementQuota, isPremium, type PremiumTier,
} from "@/lib/quota"
import { cn } from "@/lib/utils"
import { Grid2x2, Star, Search, Sparkles } from "lucide-react"
import { AnimatedOrb } from "../animated-orb"

type LockState = "loading" | "setup" | "locked" | "unlocked"

/* ── browser TTS fallback ─────────────────────────────────────── */
function browserSpeak(text: string) {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return
  window.speechSynthesis.cancel()
  const utt   = new SpeechSynthesisUtterance(text.slice(0, 300))
  utt.rate    = 1.05
  utt.pitch   = 1.0
  utt.volume  = 1.0
  const voices = window.speechSynthesis.getVoices()
  const pref   = voices.find(v => /google|samantha|zira|david/i.test(v.name))
  if (pref) utt.voice = pref
  window.speechSynthesis.speak(utt)
}

/* ── browser STT (SpeechRecognition) ─────────────────────────── */
type AnyWindow = typeof window & {
  SpeechRecognition?: new() => SpeechRecognition
  webkitSpeechRecognition?: new() => SpeechRecognition
}
function getBrowserSTT(): (new() => SpeechRecognition) | null {
  if (typeof window === "undefined") return null
  const w = window as AnyWindow
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null
}

/* ── bottom nav ────────────────────────────────────────────────── */
function BottomNav({ screen, navigate }: { screen: Screen; navigate: (s: Screen) => void }) {
  const active = "text-primary"
  const idle   = "text-muted-foreground"
  return (
    <nav className="flex items-center justify-around border-t border-border/60 bg-card/90 px-4 pb-2 pt-2 backdrop-blur-sm shrink-0">
      <button onClick={() => navigate("space")} className="flex flex-col items-center gap-0.5">
        <Sparkles className={cn("size-5 transition-colors", screen === "space" ? active : idle)} />
        <span className={cn("text-[9px] font-medium", screen === "space" ? "text-primary" : idle)}>Space</span>
      </button>
      <button onClick={() => navigate("drawer")} className="flex flex-col items-center gap-0.5">
        <Search className={cn("size-5 transition-colors", screen === "drawer" ? active : idle)} />
        <span className={cn("text-[9px] font-medium", screen === "drawer" ? "text-primary" : idle)}>Apps</span>
      </button>
      <button onClick={() => navigate("lex")} className="flex flex-col items-center active:scale-90 transition-transform duration-100" aria-label="LEX">
        <AnimatedOrb className="size-11 pointer-events-none" />
      </button>
      <button onClick={() => navigate("focus")} className="flex flex-col items-center gap-0.5">
        <Star className={cn("size-5 transition-colors", screen === "focus" ? active : idle)} />
        <span className={cn("text-[9px] font-medium", screen === "focus" ? "text-primary" : idle)}>Focus</span>
      </button>
      <button onClick={() => navigate("home")} className="flex flex-col items-center gap-0.5">
        <Grid2x2 className={cn("size-5 transition-colors", screen === "home" ? active : idle)} />
        <span className={cn("text-[9px] font-medium", screen === "home" ? "text-primary" : idle)}>Home</span>
      </button>
    </nav>
  )
}

function HomeBar() {
  return (
    <div className="flex justify-center pb-2 pt-1 shrink-0">
      <div className="h-1 w-28 rounded-full bg-foreground/20" />
    </div>
  )
}

/* ════════════════════════════════════════════════════════════════
   MAIN APP
   ════════════════════════════════════════════════════════════════ */
export function LexApp() {
  /* ── lock ── */
  const [lockState,   setLockState]   = useState<LockState>("loading")
  const [lockConfig,  setLockConfig_] = useState<LockConfig | null>(null)

  /* ── settings ── */
  const [settings, setSettings_] = useState<AppSettings>(() =>
    typeof window === "undefined" ? {
      theme: "dark", accentPreset: "amber", wallpaper: "amber",
      fontSize: "md", voiceId: "21m00Tcm4TlvDq8ikWAM", voiceName: "Rachel",
      voiceEnabled: true, autoSpeak: true, aiPersonality: "friendly", notifSound: true,
    } : loadSettings()
  )

  /* ── navigation ── */
  const [screen,    setScreen]    = useState<Screen>("home")
  const [history,   setHistory]   = useState<Screen[]>(["home"])

  /* ── data ── */
  const [weather,   setWeather]   = useState<Weather | null>(null)
  const [time,      setTime]      = useState<Date | null>(null)
  const [messages,  setMessages]  = useState<Msg[]>([])
  const [thinking,  setThinking]  = useState(false)
  const [recording, setRecording] = useState(false)
  const [notifs,    setNotifs]    = useState<Notification[]>([])
  const [notifsOpen, setNotifsOpen] = useState(false)

  /* ── weather search ── */
  const [weatherSearchOpen, setWeatherSearchOpen] = useState(false)

  /* ── payment state ── */
  const [selectedTier, setSelectedTier] = useState<PremiumTier>("pro")

  const mediaRef  = useRef<MediaRecorder | null>(null)
  const chunksRef = useRef<Blob[]>([])

  /* ── fetch weather for given coords ── */
  const loadWeather = useCallback((lat: number | string, lng: number | string) => {
    fetch(`/api/weather?lat=${lat}&lng=${lng}`)
      .then(r => r.json())
      .then(d => {
        if (!d.error) {
          setWeather(d)
          setNotifs(buildNotifications(d))
        }
      })
      .catch(() => {})
  }, [])

  /* ── use device location ── */
  const useDeviceLocation = useCallback(() => {
    if (typeof navigator !== "undefined" && navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        p => loadWeather(p.coords.latitude, p.coords.longitude),
        () => {
          // If user denies or times out, just show no weather until they pick a city
          setWeather(null)
        },
      )
    }
  }, [loadWeather])

  /* ── init ── */
  useEffect(() => {
    const s = loadSettings()
    setSettings_(s)
    applyAllSettings(s)

    const cfg = getLockConfig()
    if (!cfg?.isSetup) { setLockState("setup") }
    else { setLockConfig_(cfg); setLockState("locked") }
  }, [])

  /* ── clock (uses local device time — no hardcoded timezone) ── */
  useEffect(() => {
    setTime(new Date())
    const id = setInterval(() => setTime(new Date()), 1000)
    return () => clearInterval(id)
  }, [])

  /* ── initial weather: try device location ── */
  useEffect(() => {
    setNotifs(buildNotifications(null))
    useDeviceLocation()
  }, [useDeviceLocation])

  /* ── settings ── */
  const handleSettingsChange = useCallback((s: AppSettings) => {
    setSettings_(s); saveSettings(s); applyAllSettings(s)
  }, [])

  /* ── navigate ── */
  const navigate = useCallback((s: Screen) => {
    setHistory(h => [...h, s]); setScreen(s)
  }, [])
  const goBack = useCallback(() => {
    setHistory(h => {
      const next = h.slice(0, -1)
      if (next.length === 0) { setScreen("home"); return ["home"] }
      setScreen(next[next.length - 1])
      return next
    })
  }, [])

  /* ── TTS: ElevenLabs → Browser SpeechSynthesis ── */
  const speakReply = useCallback(async (text: string) => {
    const s = loadSettings()
    if (!s.voiceEnabled || !s.autoSpeak) return
    const snippet = text.slice(0, 300)
    try {
      const res = await fetch("/api/voice", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({ text: snippet, voiceId: s.voiceId }),
      })
      if (res.ok) {
        const blob = await res.blob()
        const url  = URL.createObjectURL(blob)
        const a    = new Audio(url)
        a.onended  = () => URL.revokeObjectURL(url)
        a.onerror  = () => { URL.revokeObjectURL(url); browserSpeak(snippet) }
        await a.play()
        return
      }
    } catch { /* fall through to browser fallback */ }
    browserSpeak(snippet)
  }, [])

  /* ── AI personality context ── */
  const getCtx = useCallback((w: Weather | null) => {
    const s = loadSettings()
    const personality =
      s.aiPersonality === "professional" ? " Respond professionally and formally." :
      s.aiPersonality === "concise"      ? " Be brief — 1-2 sentences max."       :
      " Be warm, friendly and conversational."
    const weatherCtx = w ? `Location: ${w.city}${w.country ? ", " + w.country : ""}. Weather: ${w.temp}${w.unit}, ${w.label}.` : ""
    return (weatherCtx + personality).trim()
  }, [])

  /* ── send message (with quota guard) ── */
  const sendMessage = useCallback(async (text: string) => {
    const clean = text.trim()
    if (!clean || thinking) return

    if (!isPremium()) {
      const q = getQuota()
      if (q.exhausted) { navigate("paywall"); return }
    }

    const userMsg: Msg = { role: "user", content: clean }
    setMessages(prev => [...prev, userMsg])
    setThinking(true)
    navigate("lex")
    incrementQuota()

    try {
      const res  = await fetch("/api/chat", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({ messages: [...messages, userMsg], context: getCtx(weather) }),
      })
      const data  = await res.json()
      const reply = (data.reply as string) ?? "Sorry, I couldn't process that."
      setMessages(prev => [...prev, { role: "assistant", content: reply }])
      speakReply(reply)
    } catch {
      setMessages(prev => [...prev, { role: "assistant", content: "Connection issue — please try again." }])
    } finally {
      setThinking(false)
    }
  }, [messages, thinking, weather, navigate, speakReply, getCtx])

  /* ── STT: Groq Whisper → Browser SpeechRecognition ── */
  const tryBrowserSTT = useCallback(() => {
    const SR = getBrowserSTT()
    if (!SR) {
      setMessages(prev => [...prev, { role: "assistant", content: "Voice processing failed. Please type your message." }])
      setThinking(false)
      return
    }
    const recognition = new SR()
    recognition.continuous     = false
    recognition.interimResults = false
    recognition.lang           = "en-US"
    recognition.onresult = (e: SpeechRecognitionEvent) => {
      const transcript = e.results[0]?.[0]?.transcript
      setThinking(false)
      if (transcript?.trim()) { sendMessage(transcript) }
      else { setMessages(prev => [...prev, { role: "assistant", content: "I didn't catch that — please try again." }]) }
    }
    recognition.onerror = () => {
      setThinking(false)
      setMessages(prev => [...prev, { role: "assistant", content: "Voice processing failed. Please type instead." }])
    }
    recognition.start()
  }, [sendMessage])

  const startVoice = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const mr     = new MediaRecorder(stream)
      chunksRef.current = []
      mr.ondataavailable = e => { if (e.data.size > 0) chunksRef.current.push(e.data) }
      mr.onstop = async () => {
        stream.getTracks().forEach(t => t.stop())
        setRecording(false)
        navigate("lex")
        setThinking(true)
        const blob = new Blob(chunksRef.current, { type: "audio/webm" })
        const fd   = new FormData()
        fd.append("audio", blob, "voice.webm")
        try {
          const tres  = await fetch("/api/transcribe", { method: "POST", body: fd })
          const tdata = await tres.json()
          setThinking(false)
          if (tdata.transcript?.trim()) {
            await sendMessage(tdata.transcript)
          } else {
            setMessages(prev => [...prev, { role: "assistant", content: "I didn't catch that — please try again." }])
          }
        } catch {
          tryBrowserSTT()
        }
      }
      mr.start()
      mediaRef.current = mr
      setRecording(true)
      navigate("voice")
    } catch { alert("Microphone access denied. Allow mic access to use voice.") }
  }, [navigate, sendMessage, tryBrowserSTT])

  const stopVoice = useCallback(() => { mediaRef.current?.stop(); setRecording(false) }, [])

  /* ── notifications ── */
  const openNotifications = useCallback(() => { setNotifs(ns => ns.map(n => ({ ...n, read: true }))); setNotifsOpen(true) }, [])
  const dismissNotif      = useCallback((id: string) => setNotifs(ns => ns.filter(n => n.id !== id)), [])
  const clearAllNotifs    = useCallback(() => { setNotifs([]); setNotifsOpen(false) }, [])
  const unreadCount       = notifs.filter(n => !n.read).length

  /* ── lock handlers ── */
  const handleSetupComplete = useCallback((cfg: LockConfig) => {
    setLockConfig_(cfg); setLockState("unlocked")
  }, [])
  const handleUnlock    = useCallback(() => setLockState("unlocked"), [])
  const handleLockReset = useCallback(() => { setLockConfig_(null); setLockState("setup") }, [])
  const handleChangeLock = useCallback(() => { clearLockConfig(); setLockConfig_(null); setLockState("setup") }, [])

  /* ── payment handlers ── */
  const handleSelectPlan = useCallback((tier: PremiumTier) => {
    setSelectedTier(tier)
    navigate("payment")
  }, [navigate])

  const handlePaymentSuccess = useCallback(() => {
    navigate("home")
  }, [navigate])

  /* ── wallpaper ── */
  const wallpaperStyle = WALLPAPERS[settings.wallpaper]?.gradient ?? WALLPAPERS.amber.gradient

  const shared = { screen, navigate, goBack, weather, time, messages, thinking, recording, sendMessage, startVoice, stopVoice }
  const noNav  = screen === "voice" || screen === "settings" || screen === "paywall" || screen === "payment"

  return (
    <div className="flex h-dvh w-screen items-center justify-center overflow-hidden bg-stone-950 sm:p-4">
      <div className="pointer-events-none fixed inset-0" style={{ background: wallpaperStyle }} />

      <div className="relative z-10 flex h-full w-full flex-col overflow-hidden bg-card sm:h-[min(844px,calc(100dvh-2rem))] sm:max-w-[390px] sm:rounded-[44px] sm:border sm:border-border/60 sm:shadow-2xl">

        {/* LOADING */}
        {lockState === "loading" && (
          <div className="flex h-full items-center justify-center bg-stone-950">
            <div className="size-8 rounded-full border-2 border-primary/30 border-t-primary animate-spin" />
          </div>
        )}

        {/* LOCK SETUP */}
        {lockState === "setup" && <LockSetup onComplete={handleSetupComplete} />}

        {/* LOCK SCREEN */}
        {lockState === "locked" && lockConfig && (
          <LockScreen config={lockConfig} weather={weather} time={time} onUnlock={handleUnlock} onReset={handleLockReset} />
        )}

        {/* MAIN APP */}
        {lockState === "unlocked" && (
          <>
            {/* Weather location search overlay */}
            {weatherSearchOpen && (
              <WeatherSearch
                onSelect={(lat, lng) => { loadWeather(lat, lng) }}
                onClose={() => setWeatherSearchOpen(false)}
                onUseDevice={useDeviceLocation}
              />
            )}

            <NotificationPanel open={notifsOpen} notifs={notifs} weather={weather}
              onClose={() => setNotifsOpen(false)} onDismiss={dismissNotif} onClearAll={clearAllNotifs} />

            {!notifsOpen && unreadCount > 0 && screen === "home" && (
              <button onClick={openNotifications}
                className="absolute top-3 right-16 z-30 flex items-center gap-1 rounded-full bg-primary px-2 py-0.5 text-[10px] font-bold text-primary-foreground shadow-md animate-bounce"
                style={{ animationDuration: "2s" }}>
                {unreadCount} new
              </button>
            )}

            <div className="flex flex-1 flex-col overflow-hidden">
              {screen === "home" && (
                <HomeScreen {...shared}
                  onNotifications={openNotifications}
                  onSettings={() => navigate("settings")}
                  onWeatherSearch={() => setWeatherSearchOpen(true)} />
              )}
              {screen === "lex"      && <LexScreen     {...shared} />}
              {screen === "voice"    && <VoiceScreen   {...shared} />}
              {screen === "focus"    && <FocusScreen   {...shared} />}
              {screen === "space"    && <SpaceScreen   {...shared} />}
              {screen === "drawer"   && <DrawerScreen  {...shared} />}
              {screen === "settings" && (
                <SettingsScreen {...shared}
                  settings={settings}
                  onSettingsChange={handleSettingsChange}
                  onChangeLock={handleChangeLock} />
              )}
              {screen === "paywall" && (
                <PaywallScreen {...shared} onSelectPlan={handleSelectPlan} />
              )}
              {screen === "payment" && (
                <PaymentScreen {...shared}
                  selectedTier={selectedTier}
                  onSuccess={handlePaymentSuccess} />
              )}
            </div>

            {!noNav && <BottomNav screen={screen} navigate={navigate} />}
            {!noNav && <HomeBar />}
          </>
        )}
      </div>
    </div>
  )
}
