"use client"

import { useState } from "react"
import {
  ChevronLeft, Shield, CheckCircle2, Loader2,
  User, CreditCard, Lock, Calendar, KeyRound,
} from "lucide-react"
import { PLANS, type PremiumTier, setPremium } from "@/lib/quota"
import type { AppShared } from "./types"
import { cn } from "@/lib/utils"

interface PaymentProps extends AppShared {
  selectedTier: PremiumTier
  onSuccess:    () => void
}

/* ── card number formatter ── */
function formatCardNumber(val: string) {
  return val.replace(/\D/g, "").slice(0, 16).replace(/(.{4})/g, "$1 ").trim()
}
function formatExpiry(val: string) {
  const digits = val.replace(/\D/g, "").slice(0, 4)
  if (digits.length >= 3) return digits.slice(0, 2) + "/" + digits.slice(2)
  return digits
}
function formatCVC(val: string) {
  return val.replace(/\D/g, "").slice(0, 4)
}

/* ── Luhn check ── */
function luhn(num: string) {
  let s = 0; let alt = false
  for (let i = num.length - 1; i >= 0; i--) {
    let n = parseInt(num[i], 10)
    if (alt) { n *= 2; if (n > 9) n -= 9 }
    s += n; alt = !alt
  }
  return s % 10 === 0
}

/* ── card type detector ── */
function cardType(num: string): string {
  const n = num.replace(/\s/g, "")
  if (/^4/.test(n)) return "VISA"
  if (/^5[1-5]/.test(n) || /^2[2-7]/.test(n)) return "MASTERCARD"
  if (/^3[47]/.test(n)) return "AMEX"
  if (/^6(?:011|5)/.test(n)) return "DISCOVER"
  return ""
}

export function PaymentScreen({ goBack, selectedTier, onSuccess }: PaymentProps) {
  const plan = PLANS.find(p => p.tier === selectedTier) ?? PLANS[0]

  const [name,      setName]      = useState("")
  const [cardNum,   setCardNum]   = useState("")
  const [expiry,    setExpiry]    = useState("")
  const [cvc,       setCvc]       = useState("")
  const [loading,   setLoading]   = useState(false)
  const [done,      setDone]      = useState(false)
  const [errors,    setErrors]    = useState<Record<string, string>>({})

  const detectedType = cardType(cardNum)

  /* ── validate all fields ── */
  function validate() {
    const e: Record<string, string> = {}

    if (!name.trim() || name.trim().split(" ").length < 2)
      e.name = "Enter your full name as it appears on the card."

    const rawCard = cardNum.replace(/\s/g, "")
    if (rawCard.length < 13)
      e.card = "Enter a valid card number."
    else if (!luhn(rawCard))
      e.card = "Card number is invalid."

    const [mm, yy] = expiry.split("/")
    const now = new Date()
    const expMonth = parseInt(mm, 10)
    const expYear  = parseInt("20" + yy, 10)
    if (!mm || !yy || expiry.length < 5 || expMonth < 1 || expMonth > 12)
      e.expiry = "Enter a valid expiry date (MM/YY)."
    else if (expYear < now.getFullYear() || (expYear === now.getFullYear() && expMonth < now.getMonth() + 1))
      e.expiry = "This card has expired."

    const rawCvc = cvc.replace(/\D/g, "")
    if (rawCvc.length < 3)
      e.cvc = "Enter the 3- or 4-digit security code."

    return e
  }

  const handlePay = async () => {
    const e = validate()
    setErrors(e)
    if (Object.keys(e).length > 0) return

    setLoading(true)

    /*
     * ── TODO: Replace this stub with your Stanbic Bank payment API call ──
     * The card details have been collected and validated client-side.
     * Wire in your Stanbic credentials via /api/payments to tokenise and charge.
     * Until then, payments are intentionally blocked at the backend.
     */
    const res = await fetch("/api/payments", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        tier:    selectedTier,
        amount:  plan.price,
        // card details would be tokenised here — never send raw PANs server-side in production
        cardLast4: cardNum.replace(/\s/g, "").slice(-4),
        nameOnCard: name.trim(),
      }),
    }).catch(() => null)

    setLoading(false)

    if (res?.ok) {
      setDone(true)
      setPremium(selectedTier, 30)
      setTimeout(onSuccess, 2200)
    } else {
      // Payment API not yet configured — show a clear message instead of silently granting access
      setErrors({
        submit:
          "Payment processing is not yet configured. Please use a bypass code from Settings to access premium features during this period.",
      })
    }
  }

  /* ── success screen ── */
  if (done) return (
    <div
      className="flex h-full flex-col items-center justify-center gap-5 px-8"
      style={{ background: `linear-gradient(160deg, ${plan.color1} 0%, #0a0a0a 100%)` }}
    >
      <div
        className="flex size-20 items-center justify-center rounded-full shadow-2xl"
        style={{ background: `${plan.accent}25`, border: `2px solid ${plan.accent}50` }}
      >
        <CheckCircle2 className="size-10" style={{ color: plan.accent }} />
      </div>
      <div className="text-center">
        <h2 className="text-2xl font-black text-white">Welcome to LEX {plan.name}!</h2>
        <p className="mt-2 text-sm text-white/60">Your subscription is now active. Redirecting…</p>
      </div>
    </div>
  )

  return (
    <div
      className="flex h-full flex-col overflow-hidden"
      style={{ background: `linear-gradient(160deg, #050e1f 0%, #0a0a0a 100%)` }}
    >
      {/* header */}
      <div className="flex items-center gap-3 px-5 pt-5 pb-3">
        <button onClick={goBack} className="flex size-9 items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/20 transition-colors active:scale-90">
          <ChevronLeft className="size-5" />
        </button>
        <h1 className="text-base font-bold text-white">Secure Checkout</h1>
        <Shield className="ml-auto size-4 text-green-400" />
      </div>

      <div className="flex-1 overflow-y-auto px-5 pb-8">

        {/* ── Plan summary ── */}
        <div
          className="mb-5 rounded-2xl border p-4"
          style={{
            borderColor: `${plan.accent}40`,
            background:  `linear-gradient(135deg, ${plan.color2}80 0%, ${plan.color1}cc 100%)`,
          }}
        >
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl">{plan.emoji}</span>
                <p className="text-base font-black text-white">LEX {plan.name}</p>
              </div>
              <p className="mt-0.5 text-xs text-white/60">{plan.tagline}</p>
            </div>
            <div className="text-right">
              <p className="text-2xl font-black text-white">{plan.price}</p>
              <p className="text-[10px] text-white/50">per month</p>
            </div>
          </div>
        </div>

        {/* ── Card details form ── */}
        <div className="mb-5 space-y-3">
          <p className="text-xs font-bold uppercase tracking-widest text-white/40">Card Details</p>

          {/* Name on card */}
          <div className={cn(
            "rounded-2xl border bg-white/5 divide-y divide-white/10",
            errors.name ? "border-red-500/50" : "border-white/10",
          )}>
            <div className="flex items-center gap-3 px-4 py-3">
              <User className="size-4 shrink-0 text-white/40" />
              <input
                type="text"
                value={name}
                onChange={e => { setName(e.target.value); setErrors(ev => ({ ...ev, name: "" })) }}
                placeholder="Full name on card"
                autoComplete="cc-name"
                className="flex-1 bg-transparent text-sm text-white placeholder:text-white/30 outline-none"
              />
            </div>
          </div>
          {errors.name && <p className="text-[11px] text-red-400 px-1">{errors.name}</p>}

          {/* Card number */}
          <div className={cn(
            "rounded-2xl border bg-white/5 divide-y divide-white/10",
            errors.card ? "border-red-500/50" : "border-white/10",
          )}>
            <div className="flex items-center gap-3 px-4 py-3">
              <CreditCard className="size-4 shrink-0 text-white/40" />
              <input
                type="text"
                inputMode="numeric"
                value={cardNum}
                onChange={e => { setCardNum(formatCardNumber(e.target.value)); setErrors(ev => ({ ...ev, card: "" })) }}
                placeholder="0000 0000 0000 0000"
                autoComplete="cc-number"
                className="flex-1 bg-transparent text-sm text-white placeholder:text-white/30 outline-none font-mono tracking-wider"
              />
              {detectedType && (
                <span className="shrink-0 rounded px-1.5 py-0.5 text-[10px] font-bold text-white/60 bg-white/10">
                  {detectedType}
                </span>
              )}
            </div>
          </div>
          {errors.card && <p className="text-[11px] text-red-400 px-1">{errors.card}</p>}

          {/* Expiry + CVC */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <div className={cn(
                "rounded-2xl border bg-white/5",
                errors.expiry ? "border-red-500/50" : "border-white/10",
              )}>
                <div className="flex items-center gap-3 px-4 py-3">
                  <Calendar className="size-4 shrink-0 text-white/40" />
                  <input
                    type="text"
                    inputMode="numeric"
                    value={expiry}
                    onChange={e => { setExpiry(formatExpiry(e.target.value)); setErrors(ev => ({ ...ev, expiry: "" })) }}
                    placeholder="MM/YY"
                    autoComplete="cc-exp"
                    className="flex-1 bg-transparent text-sm text-white placeholder:text-white/30 outline-none font-mono"
                  />
                </div>
              </div>
              {errors.expiry && <p className="mt-1 text-[10px] text-red-400 px-1">{errors.expiry}</p>}
            </div>
            <div>
              <div className={cn(
                "rounded-2xl border bg-white/5",
                errors.cvc ? "border-red-500/50" : "border-white/10",
              )}>
                <div className="flex items-center gap-3 px-4 py-3">
                  <KeyRound className="size-4 shrink-0 text-white/40" />
                  <input
                    type="text"
                    inputMode="numeric"
                    value={cvc}
                    onChange={e => { setCvc(formatCVC(e.target.value)); setErrors(ev => ({ ...ev, cvc: "" })) }}
                    placeholder="CVC"
                    autoComplete="cc-csc"
                    className="flex-1 bg-transparent text-sm text-white placeholder:text-white/30 outline-none font-mono"
                  />
                </div>
              </div>
              {errors.cvc && <p className="mt-1 text-[10px] text-red-400 px-1">{errors.cvc}</p>}
            </div>
          </div>
        </div>

        {/* ── Amount summary ── */}
        <div className="mb-5 rounded-2xl border border-white/10 bg-white/5 px-4 py-3">
          <div className="flex items-center justify-between">
            <span className="text-sm text-white/60">Total due today</span>
            <span className="text-base font-black text-white">{plan.price}</span>
          </div>
          <div className="mt-1 flex items-center justify-between">
            <span className="text-[11px] text-white/40">Billed monthly · Cancel anytime</span>
            <div
              className="rounded-full px-2 py-0.5 text-[10px] font-semibold"
              style={{ background: `${plan.accent}30`, color: plan.accent }}
            >
              Auto-renews
            </div>
          </div>
        </div>

        {/* ── Submit error ── */}
        {errors.submit && (
          <div className="mb-4 rounded-2xl border border-amber-500/20 bg-amber-500/10 px-4 py-3">
            <p className="text-xs font-semibold text-amber-400">⚠️ Payment unavailable</p>
            <p className="mt-1 text-[11px] text-amber-400/80">{errors.submit}</p>
          </div>
        )}

        {/* ── Pay button ── */}
        <button
          onClick={handlePay}
          disabled={loading}
          className="w-full rounded-2xl py-4 text-base font-black text-white shadow-2xl transition-all active:scale-[0.98] disabled:opacity-80"
          style={{ background: `linear-gradient(135deg, ${plan.accent}, ${plan.color2} 70%)` }}
        >
          {loading ? (
            <span className="flex items-center justify-center gap-2">
              <Loader2 className="size-4 animate-spin" /> Processing…
            </span>
          ) : (
            `Pay ${plan.price} · Subscribe`
          )}
        </button>

        {/* security row */}
        <div className="mt-4 flex items-center justify-center gap-2">
          <Lock className="size-3 text-white/30" />
          <p className="text-[11px] text-white/30">256-bit TLS encrypted · Secure payment</p>
        </div>
      </div>
    </div>
  )
}
