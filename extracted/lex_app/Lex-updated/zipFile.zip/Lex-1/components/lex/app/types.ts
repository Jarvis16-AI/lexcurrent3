export type Screen =
  | "home"
  | "lex"
  | "voice"
  | "focus"
  | "space"
  | "drawer"
  | "settings"
  | "paywall"
  | "payment"
  | "context"
  | "profile"

export interface Weather {
  temp: number
  feelsLike: number
  humidity: number
  wind: number
  label: string
  icon: string
  high: number
  low: number
  city: string
  unit: string
}

export interface Msg {
  role: "user" | "assistant"
  content: string
}

export interface Task {
  id: number
  text: string
  done: boolean
  time?: string
}

export interface AppShared {
  screen: Screen
  navigate: (s: Screen) => void
  goBack: () => void
  weather: Weather | null
  time: Date | null
  messages: Msg[]
  thinking: boolean
  recording: boolean
  sendMessage: (text: string) => Promise<void>
  startVoice: () => Promise<void>
  stopVoice: () => void
}
