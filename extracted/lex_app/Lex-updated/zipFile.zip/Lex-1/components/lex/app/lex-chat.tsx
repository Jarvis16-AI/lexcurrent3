"use client"

import { useState, useRef, useEffect } from "react"
import Image from "next/image"
import { ChevronLeft, Send, Mic, Camera, ScanLine, Folder, Loader2, Trash2, Sparkles, Zap } from "lucide-react"
import type { AppShared } from "./types"
import { cn } from "@/lib/utils"
import { AnimatedOrb } from "../animated-orb"
import { getQuota, isPremium } from "@/lib/quota"

function StatusBar({ time }: { time: Date | null }) {
  const fmt = time ? time.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : ""
  return (
    <div className="flex items-center justify-between px-6 pt-4 text-foreground">
      <span className="text-[13px] font-semibold tabular-nums">{fmt}</span>
      <span className="text-[11px] font-semibold text-primary">LEX AI</span>
    </div>
  )
}

function QuotaBar({ remaining, limit, onUpgrade }: { remaining: number; limit: number; onUpgrade: () => void }) {
  const pct     = Math.max(0, remaining / limit)
  const color   = pct > 0.4 ? "#22c55e" : pct > 0.15 ? "#f59e0b" : "#ef4444"
  const used    = limit - remaining
  const premium = isPremium()
  if (premium) return null

  return (
    <div className="mx-4 mb-1">
      <div className="flex items-center justify-between mb-1">
        <span className="text-[10px] text-muted-foreground">
          {remaining === 0
            ? "Daily limit reached"
            : `${used} of ${limit} free messages used`}
        </span>
        <button onClick={onUpgrade} className="flex items-center gap-1 text-[10px] font-semibold text-primary hover:opacity-80 transition-opacity">
          <Sparkles className="size-3" /> Upgrade
        </button>
      </div>
      <div className="h-1 w-full rounded-full bg-accent/50 overflow-hidden">
        <div
          className="h-full rounded-full transition-all duration-500"
          style={{ width: `${(used / limit) * 100}%`, background: color }}
        />
      </div>
    </div>
  )
}

const QUICK = [
  "Summarize my day",
  "What's trending?",
  "Help me write a message",
  "Tell me a quick joke",
]

export function LexScreen({ goBack, time, messages, thinking, sendMessage, startVoice, navigate }: AppShared) {
  const [input, setInput] = useState("")
  const [quota, setQuota] = useState(() => getQuota())
  const endRef            = useRef<HTMLDivElement>(null)

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages, thinking])

  /* refresh quota after each message */
  useEffect(() => {
    setQuota(getQuota())
  }, [messages.length])

  const handleSend = () => {
    const t = input.trim()
    if (!t) return
    setInput("")
    sendMessage(t)
  }

  const isLocked = quota.exhausted && !isPremium()

  return (
    <div className="flex h-full flex-col">
      <StatusBar time={time} />

      {/* header */}
      <div className="flex items-center gap-3 px-5 pt-3 pb-2">
        <button
          onClick={goBack}
          className="flex size-9 items-center justify-center rounded-full bg-accent/60 text-muted-foreground active:scale-90 transition-transform"
        >
          <ChevronLeft className="size-5" />
        </button>
        <div className="flex flex-1 items-center gap-2">
          <Image src="/lex-orb.png" alt="LEX" width={32} height={32} className="rounded-full" />
          <div className="leading-tight">
            <p className="text-sm font-bold text-primary">LEX</p>
            <p className="text-[10px] text-muted-foreground">
              {thinking ? "Thinking…" : isLocked ? "Upgrade to continue" : "Online · Ready to help"}
            </p>
          </div>
        </div>
        {messages.length > 0 && (
          <button className="flex size-8 items-center justify-center rounded-full text-muted-foreground hover:text-destructive transition-colors">
            <Trash2 className="size-4" />
          </button>
        )}
      </div>

      {/* quota bar */}
      <QuotaBar remaining={quota.remaining} limit={quota.limit} onUpgrade={() => navigate("paywall")} />

      {/* messages */}
      <div className="flex-1 overflow-y-auto px-4 py-2 space-y-3">
        {messages.length === 0 && !thinking && (
          <div className="flex flex-col items-center py-8">
            <Image src="/lex-orb.png" alt="LEX" width={80} height={80} className="rounded-full shadow-lg" priority />
            <p className="mt-4 text-base font-semibold text-foreground">What can I do for you?</p>
            <p className="mt-1 text-xs text-muted-foreground">Type below or tap 🎙 to speak</p>
            <div className="mt-6 grid grid-cols-2 gap-2 w-full">
              {QUICK.map(q => (
                <button
                  key={q}
                  onClick={() => sendMessage(q)}
                  className="rounded-2xl border border-border bg-card px-3 py-2.5 text-xs text-foreground text-left hover:bg-accent/50 active:bg-accent transition-colors"
                >
                  {q}
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map((m, i) => (
          <div key={i} className={cn("flex items-end gap-2", m.role === "user" ? "justify-end" : "justify-start")}>
            {m.role === "assistant" && (
              <Image src="/lex-orb.png" alt="LEX" width={24} height={24} className="rounded-full shrink-0 mb-0.5" />
            )}
            <div
              className={cn(
                "max-w-[78%] rounded-3xl px-4 py-2.5 text-sm leading-relaxed",
                m.role === "user"
                  ? "bg-primary text-primary-foreground rounded-br-md"
                  : "bg-popover border border-border/70 text-foreground rounded-bl-md shadow-sm",
              )}
            >
              {m.content}
            </div>
          </div>
        ))}

        {thinking && (
          <div className="flex items-end gap-2">
            <Image src="/lex-orb.png" alt="LEX" width={24} height={24} className="rounded-full" />
            <div className="rounded-3xl rounded-bl-md border border-border/70 bg-popover px-4 py-3 shadow-sm">
              <div className="flex gap-1.5">
                {[0,1,2].map(i => (
                  <span key={i} className="size-2 rounded-full bg-primary/50 animate-bounce" style={{ animationDelay: `${i * 160}ms` }} />
                ))}
              </div>
            </div>
          </div>
        )}

        {/* quota exhausted banner */}
        {isLocked && (
          <div className="flex flex-col items-center gap-3 py-4">
            <div className="rounded-2xl border border-primary/30 bg-primary/5 px-5 py-4 text-center">
              <Sparkles className="mx-auto size-7 text-primary mb-2" />
              <p className="text-sm font-semibold text-foreground">Daily limit reached</p>
              <p className="mt-0.5 text-xs text-muted-foreground">You've used all 10 free messages today. Upgrade for more.</p>
              <button
                onClick={() => navigate("paywall")}
                className="mt-3 flex items-center gap-2 rounded-full bg-primary px-5 py-2 text-xs font-bold text-primary-foreground shadow-md mx-auto active:scale-95 transition-transform"
              >
                <Zap className="size-3.5" /> Upgrade LEX
              </button>
            </div>
          </div>
        )}

        <div ref={endRef} />
      </div>

      {/* input bar */}
      <div className="px-4 pb-2">
        {isLocked ? (
          <button
            onClick={() => navigate("paywall")}
            className="flex w-full items-center justify-center gap-2 rounded-full border border-primary/40 bg-primary/10 py-3 text-sm font-semibold text-primary active:scale-[0.98] transition-transform"
          >
            <Sparkles className="size-4" /> Upgrade for unlimited messages
          </button>
        ) : (
          <div className="flex items-center gap-2 rounded-full border border-border bg-card px-4 py-3 shadow-sm">
            <input
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === "Enter" && !e.shiftKey && handleSend()}
              placeholder="Message LEX…"
              className="min-w-0 flex-1 bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground"
            />
            {input.trim() ? (
              <button
                onClick={handleSend}
                disabled={thinking}
                className="flex size-8 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-sm active:scale-90 transition-transform disabled:opacity-50"
              >
                {thinking ? <Loader2 className="size-4 animate-spin" /> : <Send className="size-4" />}
              </button>
            ) : (
              <button
                onClick={startVoice}
                className="flex size-8 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-sm active:scale-90 transition-transform"
              >
                <Mic className="size-4" />
              </button>
            )}
          </div>
        )}
      </div>

      {/* tool shelf */}
      <div className="flex items-center justify-around border-t border-border/50 px-6 py-2 text-[10px] text-muted-foreground">
        <button onClick={startVoice} className="flex flex-col items-center gap-1 hover:text-primary transition-colors active:scale-90">
          <Mic className="size-4" /><span>Voice</span>
        </button>
        <button className="flex flex-col items-center gap-1 hover:text-primary transition-colors">
          <Camera className="size-4" /><span>Camera</span>
        </button>
        <button onClick={() => navigate("home")} className="active:scale-90 transition-transform">
          <AnimatedOrb className="size-10 pointer-events-none" />
        </button>
        <button className="flex flex-col items-center gap-1 hover:text-primary transition-colors">
          <ScanLine className="size-4" /><span>Screen</span>
        </button>
        <button className="flex flex-col items-center gap-1 hover:text-primary transition-colors">
          <Folder className="size-4" /><span>Files</span>
        </button>
      </div>
    </div>
  )
}
